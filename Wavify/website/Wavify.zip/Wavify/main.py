from website import music_app

app = music_app()

if __name__ == '__main__':
    app.run(debug=True)